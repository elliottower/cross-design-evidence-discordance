
--- 

# CLOSING FILL — AD-020 to AD-026  (to ~30 total)

Per the Family-A/B/C scaffold notes: extra per-factor MR risk rows, a metabolic-treatment case,
a scored synaptic-marker substrate, and one explicit outcome-disagreement case.

---

TITLE CASE AD-020  Type-2 diabetes as a causal risk factor for AD  (Family A, per-factor MR)

Decomposed claim
- c1  T2D is observationally associated with higher dementia/AD risk.
- c2  Genetically-proxied T2D CAUSES increased AD risk (MR).
- c3  The path runs through vascular/insulin-signalling routes, not amyloid directly.
- c4  Glycaemic control lowers AD risk (interventional corollary).
View  Etiology / per-factor MR — one row of the AD-005 modifiable-risk screen.
Evidence  Mixed MR literature: some pleiotropy-robust signals, several nulls after adjustment web948.
Tier assignment  c1 T2-T3.  c2 T2-T3 MIXED — score per-instrument, pleiotropy-checked.  c3 T2-T3
vascular/parallel (coheres with AD-015).  c4 T1-T2 no clean prevention RCT.
Verdict  SUPPORTED-with-heterogeneity as a causal-modifiable candidate; treatment lever UNDERDETERMINED.
Contraction  Hard core c1. c2 held per-factor only. Discard c4 (etiology != treatment, MS 007/013 pattern).
Xia hook  Second per-factor MR row; pairs with AD-021 (education) and the TREM2/IL-6 panel (003/004)
to widen the MR-discrimination module. Vascular route ties to AD-015 and P2.

---

TITLE CASE AD-021  Educational attainment as a causal (protective) factor  (Family A / D3 bridge)

Decomposed claim
- c1  Higher education associates with lower AD risk / later onset.
- c2  Genetically-proxied education is CAUSALLY protective (MR).
- c3  The effect is reserve-mediated (expression edge), not pathology-lowering.
- c4  The MR estimate is free of the SES/confounding that plagues the observational estimate.
View  Etiology/MR with a reserve-mediation leg — the causal complement to AD-013 (D3).
Evidence  Education is a leading modifiable lever web948; MR-for-prevention framing flags confounding.
Tier assignment  c1 T3.  c2 T2-T3 (pleiotropy via cognition/SES live).  c3 T2-T3 mediation plausible.
c4 T2 — education MR is pleiotropy-prone (assortative mating, dynastic effects).
Verdict  SUPPORTED as a causal-protective candidate; the MR estimate itself carries pleiotropy debt.
Contraction  Hard core c1,c3. c2 held with explicit pleiotropy caveat. This is the MR case where the
INSTRUMENT is weakest — a useful "not all MR is equal" tier-transport example.
Xia hook  Education MR = the tier-transport (Ttier) demo: same factor, effect shifts as instrument
quality drops. Feeds extension_spec Phase 4b mechanism-by-tier matrix. Bridges A<->D3.

---

TITLE CASE AD-022  Blood pressure / midlife hypertension causal for dementia  (Family A, per-factor MR)

Decomposed claim
- c1  Midlife hypertension associates with later dementia (age-window specific).
- c2  Genetically-proxied SBP is causal for dementia/AD (MR).
- c3  Effect is vascular-mediated and age-window dependent (midlife > late-life).
- c4  BP lowering prevents dementia (interventional — SPRINT-MIND-adjacent).
View  Etiology/MR with an age-window effect-modifier leg. Vascular axis (P2 parallel edge).
Evidence  Hypertension is a top Lancet-Commission modifiable factor web948; age-window well described.
Tier assignment  c1 T3.  c2 T2-T3 MR.  c3 T3 age-window modifier.  c4 T2-T3 — BP lowering has the
STRONGEST prevention signal of the modifiable set (nearest to a positive treatment leg).
Verdict  SUPPORTED as causal-modifiable; the closest AD case to a validated PREVENTION lever.
Contraction  Hard core c1,c2,c3. c4 held cautiously (best-supported intervention in the family).
Note the age-window is an effect-MODIFIER — pooling across age glues badly (H1 != 0).
Xia hook  BP is the modifiable factor where etiology->treatment nearly CLOSES — the constructive
contrast to vitamin-D/BMI in MS (causal but no proven intervention). Third MR panel row.

---

TITLE CASE AD-023  GLP-1 / anti-diabetic repurposing as a treatment mechanism  (Family C4)

Decomposed claim
- c1  GLP-1 / metabolic agents engage vascular-metabolic and inflammatory targets in AD.
- c2  This produces biomarker movement (hsCRP, some neurodegeneration signals).
- c3  It yields clinical cognitive/functional benefit.
- c4  The metabolic axis is a viable disease-modifying lever.
View  Treatment-mechanism, metabolic axis. Extends AD-C3 (GLP-1 biomarkers moved, cognition did not).
Evidence  EVOKE/EVOKE+ (n=3,808): inflammatory/degeneration markers moved, NO CDR-SB separation over 2yr
web980/974/982.
Tier assignment  c1 T3 engagement.  c2 T3 biomarker shift.  c3 DISCONFIRMED (well-powered null) web980.
c4 T1-T2 symptomatic-stage lever unsupported.
Verdict  DISCONFIRMED for symptomatic cognitive benefit despite biomarker movement — the FOURTH
single-node engaged-but-failed result (with amyloid C1, tau C2, inflammation C3).
Contraction  Discard c3. Preserve c1,c2. Coheres with AD-004 (systemic cytokines MR-null): moving
SYSTEMIC metabolism/inflammation != moving CNS pathology. Compartment distinction holds.
Xia hook  C4 is the FOURTH engaged-but-unmoved node — strengthens AD-P2's H1 != 0 from a triple to a
quadruple dissociation. The field's combination-therapy pivot is the clinical statement of H1 != 0.

---

TITLE CASE AD-024  Synaptic markers (neurogranin, alpha-synuclein) as a substrate  (Family B5)

Decomposed claim
- c1  CSF neurogranin / alpha-synuclein index synaptic dysfunction in vivo.
- c2  They carry information beyond A, T, N (partial independence).
- c3  They are prognostic for decline.
- c4  Synaptic loss is the PROXIMAL substrate of cognition (closer than N).
View  Subspace/substrate — a candidate synaptic axis, sibling to the glial axis (AD-010).
Evidence  Synaptic markers listed among B-axis candidates (catalog_ad Family B) web940.
Tier assignment  c1 T3.  c2 T2 partial independence plausible.  c3 T2-T3.  c4 T2 — proximity claim
competes with N (AD-008) and cortical/synaptic measures; not adjudicated.
Verdict  SUGGESTIVE — a partly-independent synaptic signal; proximal-substrate primacy UNDERDETERMINED.
Contraction  Hard core c1. c2,c3 held emerging; c4 not adjudicated (rival-substrate vs N — a sheaf case).
Feeds the matroid-rank question (E2/P1): does synaptic load its own axis or collapse onto N?
Xia hook  Synaptic markers are a SECOND candidate axis beyond ATN (with glia, AD-010) — both test
whether ATN's rank is really 3. Direct input to the P1 factor-analysis axis-count deliverable.

---

TITLE CASE AD-025  Biomarker-defined vs clinical AD: the disagreement rate  (Family E5)

Decomposed claim
- c1  A measurable fraction of clinically-diagnosed AD is biomarker-negative (A-), and vice versa.
- c2  This disagreement rate is large enough to bias effect estimates that ignore it.
- c3  Enriching trials by biomarker changes the estimand (who is "AD").
- c4  Clinical and biomarker definitions can be treated interchangeably.
View  Outcome/identity validity — the quantitative core of E1. The referent-mismatch rate.
Evidence  N-axis non-specificity (AD-008) + SNAP + mixed pathology (AD-015) drive the mismatch web940.
Tier assignment  c1 T3 disagreement documented.  c2 T2-T3 bias plausible/large.  c3 T3 estimand shift
real (anti-amyloid trials are amyloid-enriched).  c4 DISCONFIRMED.
Verdict  SUPPORTED that clinical and biomarker AD disagree at a bias-relevant rate; DISCONFIRMED that
they are interchangeable. Quantifies the E1 referent problem.
Contraction  Hard core c1,c2,c3. Discard c4. Every pre-biomarker-era estimate carries a referent-drift
confound relative to biomarker-defined trials — a tier/era transport issue.
Xia hook  E5 makes E1 numeric: the disagreement rate is the size of the H1 obstruction at the
definitional level, and it quantifies why old and new AD estimates don't transport. Pairs with E2/E3.

---

TITLE CASE AD-026  Down syndrome as a natural genetic model of AD  (Family A / cross-validation)

Decomposed claim
- c1  Trisomy-21 (APP triplication) produces near-universal AD neuropathology.
- c2  This is a near-DETERMINISTIC genetic dose effect on amyloid (a natural experiment).
- c3  Biomarker trajectories (incl. p-tau217) recapitulate sporadic AD ordering.
- c4  DS validates the amyloid-INITIATION leg of the cascade (AD-001 c2/c3).
View  Etiology — a natural genetic-dose instrument for the amyloid-initiation claim.
Evidence  p-tau217 validated in Down syndrome (AD-009) web963; APP-dose -> amyloid is near-deterministic.
Tier assignment  c1 T4.  c2 T3-T4 dose-deterministic.  c3 T3 trajectory recapitulation.  c4 T3 — DS
supports INITIATION but not SUFFICIENCY (DS also has non-amyloid contributions).
Verdict  SUPPORTED as strong evidence for amyloid INITIATION (AD-001 c2/c3); does NOT rescue the strong
SUFFICIENCY cascade (consistent with AD-P2).
Contraction  Hard core c1,c2,c3. c4 held for initiation only. DS is the near-necessity/dose instrument
analogous to MS EBV-necessity (001) — strongest natural-experiment support for the trigger leg.
Xia hook  DS is the AD analogue of the EBV temporal-necessity design: a genetic-dose natural experiment
that isolates the initiation leg. A clean tier-3 causal anchor and a cross-validation of AD-001/009.

---

# FINAL AD TALLY

Family  | Cases                                  | Count
A Etiology / causal-risk        | AD-001..005, 020,021,022, 026  | 9
B Progression substrate (ATNI)  | AD-006..010, 024               | 6
C Treatment-mechanism           | AD-C1,C2,C3, 023               | 4
P2 Flagship adjudication        | AD-P2                          | 1
D Effect-modification/transport | AD-011..015                    | 5
E Foundational / outcome-valid. | AD-016..019, 025               | 5
TOTAL                                                            | 30   <- TARGET MET

MR panel now: TREM2 (+, 003), IL-6 (null, 004), T2D (020), education (021), BP (022) — 5-factor
positive/negative discrimination set, matching the MS wide-angle atlas structure.
Engaged-but-failed treatment nodes now QUADRUPLE: amyloid (C1), tau (C2), inflammation (C3),
metabolic (C4=023) — strengthens AD-P2 H1 != 0.
