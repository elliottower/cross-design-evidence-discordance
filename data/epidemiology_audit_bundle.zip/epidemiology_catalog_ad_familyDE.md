
--- 

# FAMILY D — EFFECT-MODIFICATION / HETEROGENEITY / TRANSPORT  (FIRST FILL)

The MS catalog's H1-non-transport lessons (OCB prognosis 006, phenotype-dependent atrophy 010,
age/activity-modified anti-CD20 011) predict that AD effects are stratum-specific, not global.
Family D scores the modifiers directly. Each is an H1 != 0 (non-transport) candidate.

---

TITLE CASE AD-011  APOE4 x amyloid interaction on tau accumulation / cognitive decline  (D1)

Decomposed claim
- c1  Amyloid burden predicts tau accumulation and cognitive decline (main effect).
- c2  APOE4 MODIFIES the amyloid->tau slope — carriers convert amyloid to tau faster (interaction).
- c3  The interaction is on tau spread specifically, not merely additive risk (mechanism-specific).
- c4  The APOE4 x amyloid interaction is the SINGLE dominant modifier of the A->T edge.
View  Effect-modification on a specific cascade EDGE (A->T). DIRECT analogue of MS HLAxEBV (018).
Evidence
- APOE4 amplifies amyloid-associated tau and accelerates decline in amyloid-positive carriers web939/web933.
- Neuronal APOE4 independently drives tau even partly OFF the amyloid path (see AD-002-c3) web935.
Tier assignment
- c1 T3 well-replicated main effect.  c2 T3 interaction reproduced across cohorts web939.
- c3 T2-T3 tau-specific modification supported, mechanism partial.  c4 T2 dominant-modifier claim overreaches — sex (D2) and reserve (D3) also modify.
Verdict  SUPPORTED as a real A->T effect-modifier; OVERREACH as the SOLE dominant modifier.
Contraction  Hard core c1,c2,c3. Discard the "single dominant" reading of c4 — this is the
multi-modifier version of the MS effect-modifier lesson; modifiers stack, they don't monopolize.
Because APOE4 also acts OFF the amyloid edge (AD-002), part of c2 is a PARALLEL path, not pure
interaction — a mediation/interaction confound that the sheaf adjudication (P2) must separate.
Xia hook  The A->T edge with APOE4 as modifier is the cleanest single-edge H1 test: does the
amyloid->tau effect GLUE across APOE4 strata, or is it a stratum-specific section? Direct P3 target.

---

TITLE CASE AD-012  Sex: female preponderance and faster tau spread  (D2)

Decomposed claim
- c1  AD prevalence is higher in women (descriptive, partly survival-confounded).
- c2  Women show FASTER tau spread / steeper decline at matched amyloid (progression modifier).
- c3  The sex effect INTERACTS with APOE4 (e4e4 women OR 12-15, see AD-002c) — non-additive.
- c4  Sex is a biological driver, not a measurement/longevity artifact.
View  Effect-modification on the T axis + a sex x gene interaction. Analogue of MS sex effects (020).
Evidence
- e4e4 women OR 12-15 vs heterozygous 3.5-4 — a documented sex x APOE4 interaction web956.
- Faster female tau spread reported at matched amyloid burden (Family-D scaffold, catalog_ad).
Tier assignment
- c1 T2-T3 prevalence robust but survival-confounded.  c2 T2-T3 tau-spread modifier.
- c3 T3 sex x APOE4 interaction quantified web956.  c4 T2 biology-vs-artifact not fully resolved.
Verdict  SUPPORTED as an APOE4-interacting sex modifier of tau/decline; UNDERDETERMINED whether
the main-effect prevalence gap is biological vs longevity/diagnosis artifact.
Contraction  Hard core c2,c3. Weaken c1 (survival/ascertainment confound) and c4 (artifact live).
The sex x APOE4 non-additivity means sex-pooled APOE4 ORs are a NON-TRANSPORT hazard — pooling
across sex strata glues badly. Textbook H1 != 0.
Xia hook  Sex is the second stacked modifier after D1. A sex-stratified APOE4-dose transport test
is the AD twin of MS 020; feeds the "modifiers stack" refutation of AD-011-c4.

---

TITLE CASE AD-013  Cognitive / brain reserve modifies the pathology->cognition link  (D3)

Decomposed claim
- c1  Education/occupation/IQ (reserve proxies) associate with later clinical onset at equal pathology.
- c2  Reserve MODIFIES the pathology->cognition slope — high reserve flattens it (interaction).
- c3  Reserve acts on the CLINICAL EXPRESSION edge (N->cognition), not on pathology accrual.
- c4  Reserve is causal/modifiable, not a proxy for a confounder (SES, vascular, measurement).
View  Effect-modification on the pathology->cognition edge. DIRECT analogue of MS reserve (031).
Evidence
- Reserve is a leading modifiable lever in the midlife-risk framing (AD-005) web948.
- Reserve decouples pathology from cognition — the canonical "resilience" phenomenon.
Tier assignment
- c1 T3 robust epidemiology.  c2 T2-T3 slope-modification supported.
- c3 T2-T3 acts on expression edge.  c4 T2 causal-vs-confounded (SES) NOT resolved — MR needed.
Verdict  SUPPORTED as a modifier of clinical expression; UNDERDETERMINED as a causal/modifiable lever
(reserve proxies are confound-laden — the AD-005 per-factor MR screen applies here too).
Contraction  Hard core c1,c2,c3. Discard the strong causal reading of c4 pending per-proxy MR —
this is the etiology->intervention gap (MS 007/013) reappearing on a MODIFIER.
Reserve is also an OUTCOME-VALIDITY issue: it distorts cognitive scales (feeds E3).
Xia hook  Reserve is the modifier that most contaminates the outcome axis — it links Family D to
Family E. A reserve-stratified pathology->cognition gluing test is the P3 case that most needs the
E3 scale-invariance preprocessing FIRST (exact analogue of MS EDSS-linearization before 016).

---

TITLE CASE AD-014  Ancestry / transportability: ADNI is White-majority  (D4)

Decomposed claim
- c1  Most AD biomarker/genetic estimates derive from White-majority cohorts (ADNI) — descriptive.
- c2  APOE4 effect magnitude DIFFERS by ancestry (e.g., attenuated in some African-ancestry samples).
- c3  Plasma p-tau217 cutoffs / Centiloid thresholds do not transport unchanged across populations.
- c4  Pooled/global estimates are valid for non-represented populations (transportability claim).
View  Transportability across ancestry — the population-level H1 obstruction. Analogue of MS 047.
Evidence
- APOE4 non-homogeneity flagged (e2e4 not elevated; non-APOE PRS modifies e4) web952/web955.
- ADNI White-majority composition is the explicit transportability limit (Family-D scaffold).
Tier assignment
- c1 T3-T4 well-documented cohort composition.  c2 T2-T3 ancestry-varying APOE4 magnitude.
- c3 T2 threshold non-transport plausible, under-tested.  c4 DISCONFIRMED as a blanket claim.
Verdict  SUPPORTED that estimates are ancestry-conditioned; DISCONFIRMED that they transport
unchanged. This is the cleanest population-level non-transport case in either catalog.
Contraction  Hard core c1,c2. Discard c4. c3 held as under-tested. The whole Family-B threshold
apparatus (Centiloid 006, p-tau217 009) inherits this: a cutoff calibrated on ADNI is a
STRATUM-SPECIFIC section, not a global one.
Xia hook  Ancestry is the modifier where H1 != 0 has the highest stakes (equity + validity). A
formal transportability check of p-tau217 cutoffs across ancestry is a direct P3/P4 deliverable and
a shared limitation to state explicitly to Xia (matches extension_spec "WHAT TO TELL XIA ABOUT LIMITS").

---

TITLE CASE AD-015  Vascular comorbidity / mixed dementia contribution  (D5)

Decomposed claim
- c1  Vascular pathology co-occurs with AD pathology in a large fraction of clinical dementia.
- c2  Vascular burden MODIFIES the AD-pathology->cognition slope (additive/synergistic).
- c3  A substantial share of "AD" clinical syndrome is MIXED, not pure — identity-blurring.
- c4  Vascular factors act via a PARALLEL, partly-independent axis (not through amyloid).
View  Comorbidity effect-modification + a partial-independence claim. Analogue of MS 032.
Evidence
- Vascular/metabolic midlife factors are causal-modifiable in the risk framing (AD-005) web948.
- Mixed pathology is the norm at autopsy — feeds the "one disease or syndrome?" question (E1).
Tier assignment
- c1 T3 autopsy-robust.  c2 T2-T3 synergy supported.  c3 T2-T3 mixed-pathology prevalence high.
- c4 T2-T3 parallel-axis (GLP-1/vascular) consistent with the P2 multi-process DAG.
Verdict  SUPPORTED that vascular burden co-drives and modifies clinical AD; this REFRAMES a share of
"AD" as mixed — a direct input to the identity case E1.
Contraction  Hard core c1,c2. c3,c4 held as strong. Vascular co-pathology is a CONFOUNDER for every
amyloid->cognition estimate (AD-C1's modest effect is partly vascular dilution) and a PARALLEL edge
in P2 — it is BOTH a modifier and a rival-process node.
Xia hook  Vascular is the modifier that feeds the flagship P2 (extra parallel edge) AND the identity
question E1. Mixed-pathology stratification is a sheaf-gluing test: does amyloid->cognition glue
across vascular-burden strata? Predicts H1 != 0 — the same signature as anti-amyloid's modest effect.

---

# FAMILY E — FOUNDATIONAL IDENTITY / OUTCOME-VALIDITY  (FIRST FILL)

Family E sits UNDER everything, exactly as MS EDSS-validity (015) underwrote every MS progression
claim. If the disease identity is a syndrome and the cognitive outcome is non-invariant, then every
Family-A/B/C estimate inherits a construct-validity discount.

---

TITLE CASE AD-016  Is AD one disease or a syndrome? (amyloid+ vs SNAP vs mixed)  (E1)

Decomposed claim
- c1  "AD" as clinically diagnosed is heterogeneous: amyloid+, SNAP (suspected non-AD path), mixed.
- c2  Biomarker-defined AD (A+T+) is a distinct entity from clinical-syndrome AD.
- c3  A single unified disease construct is valid and licenses pooling across these subgroups.
- c4  The biological (ATN) definition should REPLACE the clinical construct.
View  Foundational identity / construct-validity — the referent-fixing case. Analogue of MS 052.
Evidence
- Mixed pathology is common (AD-015); N axis is non-specific (AD-008) web940; SNAP is well-described.
- P2 shows no single linear cause — arguing "AD" names a convergence, not one mechanism (AD-P2).
Tier assignment
- c1 T3 heterogeneity robust.  c2 T3 biomarker-clinical divergence documented.
- c3 DISCONFIRMED as stated — pooling across amyloid+/SNAP/mixed glues badly.  c4 T2 contested reframing.
Verdict  SUPPORTED that "AD" is a heterogeneous syndrome with a biomarker-definable core;
DISCONFIRMED that one construct licenses uniform pooling. The identity is stratified, not singular.
Contraction  Hard core c1,c2. Discard c3. c4 held as an open reframing (ATN, see E2). This is the
AD MechRef referent-fixing case: what does "AD" REFER TO? Different measures fix different referents,
and estimates do not transport across referents — the H1 obstruction at the DEFINITIONAL level.
Xia hook  E1 is where the whole catalog's transport logic bottoms out: if the referent isn't fixed,
no downstream effect transports. The amyloid+/SNAP/mixed split is the coarsest sheaf-stratification;
every Family-A/B estimate should be re-scored WITHIN a fixed referent. Foundational, like MS 015.

---

TITLE CASE AD-017  ATN as a re-metricization of AD into (A,T,N) coordinates  (E2)

Decomposed claim
- c1  ATN re-expresses AD on 3 measurable biological axes (A, T, N) rather than one clinical label.
- c2  The 3 axes are (partly) INDEPENDENT — carry non-redundant information.
- c3  ATN (or ATNI, +inflammation) is the correct coordinate system for the disease.
- c4  The number of independent axes is exactly 3 (or 4 with I).
View  Re-metricization / coordinate-choice — the constructive twin of E1. Explicit multi-axis framing.
Evidence
- Community has PRE-COMMITTED to A,T,N (stronger start than MS) — but glial/I axis proposed (AD-010).
- P2 multi-process DAG supports partial independence; APOE4 acts on multiple axes (AD-002) web933/935.
Tier assignment
- c1 T3-T4 axes are measurable/standardized.  c2 T2-T3 partial independence — NOT orthogonality.
- c3 T2-T3 useful coordinate system, not proven canonical.  c4 T1-T2 axis-COUNT is empirically open.
Verdict  SUPPORTED as a productive re-metricization; the EXACT axis count (3 vs 4 vs collapsing to fewer)
is UNDERDETERMINED and must be MEASURED, not assumed.
Contraction  Hard core c1,c2. Discard the fixed-count reading of c4. The claim "ATN = 3 independent
axes" is a MATROID-RANK question, not a definition — glial/I may load on A or N and reduce rank.
Xia hook  E2 is the P1 matroid-rank / factor-analysis flagship: run parallel analysis on ADNI ATN(I)
to ESTIMATE the number of independent substrate dimensions. Prediction (extension_spec Phase 4a):
ATN collapses to FEWER than 4 independent axes; glial loads on both. Direct numeric structural test.

---

TITLE CASE AD-018  Cognitive-scale invariance: MMSE / CDR-SB / ADAS-cog  (E3)

Decomposed claim
- c1  MMSE / CDR-SB / ADAS-cog validly measure the cognitive-decline construct.
- c2  They are sensitive to change across the full disease range (no floor/ceiling).
- c3  A fixed score change means the same thing everywhere on the scale (linearity/invariance).
- c4  These scales are sensitive enough to detect clinically meaningful treatment effects.
View  Construct-validity / measurement-invariance — sits UNDER every Family-C efficacy claim.
DIRECT analogue of MS EDSS validity (015). Underwrites AD-C1/C2/C3 and AD-P2's "modest benefit".
Evidence
- Lecanemab benefit debated as near/below MCID on CDR-SB (AD-C1) web975/972 — a sensitivity problem.
- Practice effects, ceiling in preclinical, floor in severe — well-known scale pathologies.
Tier assignment
- c1 T3 validated for cognition.  c2 T2 floor/ceiling limits.  c3 DISCONFIRMED — non-linear/non-invariant.
- c4 T1-T2, CONTESTED — MCID debate on CDR-SB is exactly a sensitivity failure web975.
Verdict  SUPPORTED as cognitive measures; WEAK/DISCONFIRMED as linear, invariant, treatment-sensitive
progression measures — the EXACT EDSS (015) verdict, re-derived in AD.
Contraction  Hard core c1. Discard c3. c2,c4 weakened. FOUNDATIONAL and PROPAGATING: the AD-C1 "modest
effect" and the anti-tau/GLP-1 nulls (C2/C3) are all read through a non-invariant lens — part of the
"is the effect small, or is the ruler bad?" ambiguity (mirrors MS remyelination 014 measurement bottleneck).
Xia hook  E3 is where the cross-view-invariance / IRT machinery earns its keep AGAIN: re-express
cognitive decline on a properly-metric latent axis BEFORE scoring any Family-C effect — the AD twin of
EDSS-linearization. This makes the invariance paper the methodological PREREQUISITE for BOTH domains.

---

TITLE CASE AD-019  Preclinical / prodromal / MCI / dementia staging: continuum vs discrete  (E4)

Decomposed claim
- c1  AD progresses through preclinical -> MCI -> dementia stages (staging framework).
- c2  These stages are DISCRETE, clinically meaningful thresholds.
- c3  Stage transitions map cleanly onto biomarker thresholds (A+ -> T+ -> N+).
- c4  A continuum model and a discrete-stage model are empirically distinguishable AND the discrete one wins.
View  Staging / thresholding validity — the temporal analogue of E1/E3. Analogue of MS PIRA staging (036).
Evidence
- Biomarker cascade is continuous (AD-006/009), thresholds are soft brackets (Centiloid 20-25 CL, AD-006).
- p-tau217 predicts transition years ahead (AD-009c HR 6.6) — arguing continuum, not step web961.
View note  Staging cuts a continuum; the cut points are bracket-norm thresholds, not natural joints.
Tier assignment
- c1 T3 staging is operationally useful.  c2 T2 discreteness is imposed, not intrinsic.
- c3 T2-T3 threshold-mapping soft (inherits AD-006 c4 bracket).  c4 DISCONFIRMED strong form — continuum fits.
Verdict  SUPPORTED as a useful operational staging; DISCONFIRMED that stages are discrete natural kinds —
the continuum model fits, and stage cutoffs are bracket-norm artifacts.
Contraction  Hard core c1. Discard the discreteness of c2 and the strong c4. Staging thresholds are the
TEMPORAL version of the E3 non-invariance and the AD-006 Centiloid bracket — every "converter" definition
inherits a threshold-choice confound.
Xia hook  E4 is the staging-as-thresholding bracket case: converter status depends on cutoff choice, so
"time-to-conversion" outcomes carry a bracket-norm confound. Pairs with E3 (outcome axis) and AD-009 Cox
(the p-tau217 progression model in extension_spec Phase 3b-ii) — linearize the axis, soften the threshold,
THEN run survival.

---

# UPDATED AD TALLY (post Families D + E)

Family  | Cases | Count
A Etiology / causal-risk        | AD-001..005                | 5
B Progression substrate (ATNI)  | AD-006..010                | 5
C Treatment-mechanism           | AD-C1, C2, C3              | 3
P2 Flagship adjudication        | AD-P2                      | 1
D Effect-modification/transport | AD-011..015 (D1..D5)       | 5   <- NEW
E Foundational / outcome-valid. | AD-016..019 (E1..E4)       | 4   <- NEW
TOTAL                                                        | 23  (target ~30)

Gap to ~30: ~7 cases. Suggested next fill (per catalog scaffold notes):
 - A: 1-2 more per-factor MR risk rows (T2D, lipids, education) to feed the AD MR panel (AD-005 screen).
 - C: C4 repurposed metabolic / anti-diabetic as a distinct treatment-mechanism case.
 - B: split synaptic markers (neurogranin, alpha-synuclein) into a scored B5 case.
 - E: an explicit E5 "biomarker-defined vs clinical AD disagreement rate" case if desired.

# CROSS-DOMAIN NOTE (D+E)
Family D re-derives the MS H1-non-transport lessons independently: APOE4xamyloid = HLAxEBV (018);
ancestry transportability = MS 047; reserve = MS 031; vascular-mixed = MS 032; sex = MS 020.
Family E re-derives the MS foundational move: AD cognitive-scale non-invariance (E3) = EDSS (015),
so the cross-view-invariance paper is now the shared methodological PREREQUISITE for BOTH halves of
Xia's program — the strongest generalization result to bring to the meeting.
