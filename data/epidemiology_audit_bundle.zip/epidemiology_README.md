# MechVal Neuroepidemiology Validity Audit — deliverable bundle (2026-07-02)

## Catalog expansion (AD -> 30 cases)
- catalog_ad_familyDE.md   : Family D (AD-011..015) + Family E (AD-016..019), full MS-style template
- catalog_ad_closing.md    : closing fill AD-020..026 -> AD total = 30 (target met)

## Quantitative extension (Phase 1-2)
- mechval_effect_sizes_v2.csv : 29 rows, 24 numeric, full provenance + gap_reason
- mechval_risk_forest.png     : risk-ratio forest, Kendall tau=0.41 p=0.069 n=14 (DESCRIPTIVE)
- mechval_pooled_estimates.csv: pooling attempt (blocked: rows lack CIs -> fill first)
- mechval_pubmed_fill.py      : eutils gap-fill scaffold (run outside sandbox; captures est+CI)
- mechval_meta.py             : DerSimonian-Laird pooling (homogeneous clusters only)
- QC_report.md                : gap audit + next-action ordering

## Status
- AD catalog: 14 -> 30 cases (A=9 B=6 C=4 P2=1 D=5 E=5).
- MR panel: TREM2(+), IL-6(null), T2D, education, BP = 5-factor discrimination set.
- Treatment engaged-but-failed nodes: quadruple (amyloid/tau/inflammation/metabolic) -> P2 H1!=0.
- Calibration still DESCRIPTIVE (n=14 risk ORs); n>=30 needs the eutils fill (Phase 1 next).

## Guardrails honored
No fabricated estimates; missing -> NaN + gap_reason; no cross-scale pooling; MR vs observational tagged.
